﻿PARAMETERS: componentId TcpPort [friendComponentId FriendPort]

WOULD YOU LIKE TO UPDATE THIS EXAMPLE TO USE A Mode-View-ViewModel? REQUEST JOIN HERE mailto:mmerayo30@gmail.com OR HERE http://code.google.com/p/ermex/